/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checkfile.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: isgandou <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/02/06 14:48:55 by isgandou          #+#    #+#             */
/*   Updated: 2018/02/13 16:06:46 by isgandou         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fillit.h"

char		*ft_read(const int fd)
{
	char	buf[547];
	int		ret;

	if (!(ret = read(fd, buf, 546)))
		return (0);
	buf[ret] = '\0';
	return (ft_strdup(buf));
}

int			ft_checklen(char *s)
{
	int		i;

	i = 0;
	while (s[i])
	{
		if (s[545] != '\0')
			return (0);
		i++;
	}
	return (1);
}

int			ft_checkback(char *s)
{
	if (s[ft_strlen(s) - 2] == '\n')
		return (0);
	return (1);
}

int			ft_checkendl(char *s)
{
	int		count;
	int		i;
	int		line;

	count = 0;
	i = 0;
	line = 0;
	while (s[i])
	{
		if (s[i] == '\n')
		{
			if (i == 4 + 5 * line + count)
				line++;
			else
			{
				count++;
				if (i != 4 + 5 * (line - 1) + count)
					return (0);
			}
		}
		i++;
	}
	return (1);
}

int			ft_checkchar(char *s)
{
	int		i;

	i = 0;
	while (s[i])
	{
		if (s[i] != '#' && s[i] != '.' && s[i] != '\n')
			return (0);
		i++;
	}
	return (1);
}
