/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fillit.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: isgandou <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/02/05 17:26:26 by isgandou          #+#    #+#             */
/*   Updated: 2018/02/13 16:03:24 by isgandou         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FILLIT_H
# define FILLIT_H

# include "../libft/libft.h"
# include <sys/types.h>
# include <sys/stat.h>
# include <fcntl.h>

char	*ft_read(const int fd);
int		ft_checkback(char *s);
int		ft_checkchar(char *s);
int		ft_checkcontactblock(char *s);
int		ft_checkendl(char *s);
int		ft_checklen(char *s);
int		ft_checknbblock(char *s);
int		ft_checkposblock(char *s);

#endif
