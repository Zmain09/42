/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: isgandou <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/02/05 16:26:02 by isgandou          #+#    #+#             */
/*   Updated: 2018/02/13 12:48:02 by isgandou         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fillit.h"
#include <stdio.h>

int			main(int ac, char **av)
{
	int		fd;

	if (ac != 2)
	{
		ft_putendl("usage : fillit source_file");
		return (0);
	}
	fd = open(av[1], O_RDONLY);
	printf("%d", ft_checkposblock(ft_read(fd)));
	close(fd);
	return (0);
}
