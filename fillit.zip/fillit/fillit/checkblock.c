/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checkblock.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: isgandou <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/02/13 12:19:36 by isgandou          #+#    #+#             */
/*   Updated: 2018/02/13 16:04:43 by isgandou         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fillit.h"

int			ft_checknbblock(char *s)
{
	int		count;
	int		i;

	count = 0;
	i = 0;
	while (s[i])
	{
		if (s[i] == '#')
		{
			if (count < 4)
				count++;
			else
				return (0);
		}
		if (s[i] == '\n' && s[i + 1] == '\n')
		{
			if (count != 4)
				return (0);
			count = 0;
		}
		i++;
	}
	return (1);
}

int			ft_checkposblock(char *s)
{
	int		count;
	int		i;
	char	*tmp;

	count = 0;
	i = 0;
	while (s[i])
	{
		if (!(tmp = ft_strsub(s, i, 20)))
			return (0);
		if (ft_checkcontactblock(tmp) == 0)
			return (0);
		free(tmp);
		count++;
		i = 20 * count + count;
	}
	return (1);
}

int			ft_checkcontactblock(char *tmp)
{
	int		i;
	int		contact_ok;

	i = 0;
	contact_ok = 0;
	while (tmp[i])
	{
		if (tmp[i] == '#')
		{
			if (tmp[i + 1] && tmp[i + 1] == '#')
				contact_ok++;
			if (tmp[i - 1] && tmp[i - 1] == '#')
				contact_ok++;
			if (tmp[i + 5] && tmp[i + 5] == '#')
				contact_ok++;
			if (tmp[i - 5] && tmp[i - 5] == '#')
				contact_ok++;
		}
		i++;
	}
	if (contact_ok > 3)
		return (1);
	return (0);
}
