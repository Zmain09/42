/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vjauze <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/01/10 14:50:27 by vjauze            #+#    #+#             */
/*   Updated: 2018/01/13 17:13:06 by vjauze           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strjoin(char const *dst, char const *src)
{
	char	*str;
	size_t	i;
	size_t	j;

	j = 0;
	i = 0;
	if (!dst || !src)
		return (NULL);
	i = ft_strlen(dst) + ft_strlen(src);
	str = (char *)malloc(sizeof(char) * i + 1);
	if (str == NULL)
		return (NULL);
	i = 0;
	while (i < ft_strlen(dst))
	{
		str[i] = dst[i];
		i++;
	}
	while (i < ft_strlen(dst) + ft_strlen(src))
	{
		str[i++] = src[j++];
	}
	str[i] = '\0';
	return (str);
}
