/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strmap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vjauze <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/01/10 14:50:04 by vjauze            #+#    #+#             */
/*   Updated: 2018/01/10 14:51:39 by vjauze           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strmap(char const *s, char (*f) (char))
{
	size_t	i;
	size_t	y;
	char	*str_s;

	if (s != NULL)
	{
		i = 0;
		y = ft_strlen(s);
		if (!(str_s = ft_strnew(y)))
			return (NULL);
		while (i < y)
		{
			str_s[i] = f(s[i]);
			i++;
		}
		return (str_s);
	}
	return (NULL);
}
