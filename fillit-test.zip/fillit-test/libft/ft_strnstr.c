/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vjauze <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/01/10 14:23:06 by vjauze            #+#    #+#             */
/*   Updated: 2018/01/13 17:10:24 by vjauze           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strnstr(const char *s1, const char *s2, size_t n)
{
	int			i;
	const char	*ret;

	if (*s2 == '\0')
		return ((char *)s1);
	while (*s1 != '\0' && n > 0)
	{
		i = 0;
		ret = s1;
		while ((s2[i] == s1[i]) && (s2[i] != '\0') && ((i - n) > 0))
			i++;
		if (s2[i] == '\0')
			return ((char *)ret);
		s1++;
		n--;
	}
	return (NULL);
}
