/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vjauze <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/01/10 14:27:42 by vjauze            #+#    #+#             */
/*   Updated: 2018/01/10 14:28:09 by vjauze           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdlib.h>

char	*ft_strdup(const char *src)
{
	int		i;
	size_t	y;
	char	*dup_s;

	i = 0;
	y = ft_strlen((char *)src);
	if (!(dup_s = (char *)malloc(sizeof(char) * (y + 1))))
		return (NULL);
	while (src[i] != '\0')
	{
		dup_s[i] = src[i];
		i++;
	}
	dup_s[i] = '\0';
	return (dup_s);
}
