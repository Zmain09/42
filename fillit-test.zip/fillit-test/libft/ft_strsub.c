/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strsub.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vjauze <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/01/10 14:47:28 by vjauze            #+#    #+#             */
/*   Updated: 2018/01/10 14:48:05 by vjauze           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strsub(char const *s, unsigned int start, size_t len)
{
	unsigned int	i;
	char			*dst;

	if (s)
	{
		i = 0;
		dst = (char *)malloc(len + 1);
		if (dst == 0)
			return (NULL);
		while (i < len)
		{
			dst[i] = s[start + i];
			i++;
		}
		dst[i] = '\0';
		return (dst);
	}
	return (0);
}
