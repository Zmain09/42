/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tetriminos.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: isgandou <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/02/13 14:11:37 by isgandou          #+#    #+#             */
/*   Updated: 2018/07/05 12:59:52 by vjauze           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fillit.h"

int		ft_create_tetriminos(char *s)
{
	int 		i;
	int 		count;
	char		*tmp;
	int		nb_tetriminos;
	list_tetriminos	newList;

	i = 0;
	count = 0;
	newList = NULL;
	nb_tetriminos = ft_nbtetrimino(s);
	while (count < nb_tetriminos)
	{
		if (!(tmp = ft_strsub(s, i, 20)))
			return (0);
		if (!(newList = addTetrimino(newList,
ft_replace_tetrimino(ft_init_tetrimino_tab(
ft_define_letter_tetrimino(tmp, count))), count)))
			return (0);
		free(tmp);
		count++;
		i = 20 * count + count;
	}
	ft_init_solve(newList, nb_tetriminos);
	return (nb_tetriminos);
}

char		**ft_init_tetrimino_tab(char *s)
{
	int 	i;
	char	**tab;

	i = 0;
	if (!(tab = malloc(sizeof(*tab) * 4)))
		return (NULL);
	while (i < 4)
	{
		if(!(tab[i] = malloc(sizeof(**tab) * 4)))
			return (NULL);
		i++;
	}
	return (ft_strtotab(tab, s));
}

char	**ft_strtotab(char **tab, char *s)
{
	int i;
	int j;
	int k;

	i = 0;
	j = 0;
	k = 0;
	while (i < 4)
	{
		j = 0;
		while (j < 4)
		{
			if (s[k] != '\n')
			{
				tab[i][j] = s[k];
				j++;
			}
			k++;
		}
		i++;
	}
	return (tab);
}

list_tetriminos	addTetrimino(list_tetriminos list, char **tab, int letter)
{
	Tetrimino* newTetrimino = malloc(sizeof(Tetrimino));
	newTetrimino->tab = tab;
	newTetrimino->letter = 'A' + letter;
	newTetrimino->next = NULL;
	if (list == NULL)
		return (newTetrimino);
	else
	{
		Tetrimino* temp = list;
		while (temp->next != NULL)
			temp = temp->next;
		temp->next = newTetrimino;
		return (list);
	}
}


int 		ft_nbtetrimino(char *s)
{
	int i;
	int	nb_total;

	i = 0;
	nb_total = 0;
	while (s[i])
	{
		if (s[i] == '\n' && (s[i + 1] == '\n' || s[i + 1] == '\0'))
			nb_total++;
		i++;
	}
	return (nb_total);
}
