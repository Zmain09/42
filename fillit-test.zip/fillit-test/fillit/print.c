/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: isgandou <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/02/13 14:11:37 by isgandou          #+#    #+#             */
/*   Updated: 2018/07/05 13:10:52 by vjauze           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fillit.h"
#include <stdio.h>

char		**create_final_tab(char **tab, int square_max)
{
	int		i;
	int		j;

	i = 0;
	j = 0; 
	if (!(tab = malloc(sizeof(*tab) * square_max)))
		return (NULL);
	while (i < square_max)
	{
		if (!(tab[i] = malloc(sizeof(*tab) * square_max)))
			return (NULL);
		i++;
	}
	i = 0;
	while (i < square_max)
	{
		j = 0;
		while (j < square_max)
		{
			tab[i][j] = '.';
			j++;
		}
		i++;
	}
	return (tab);
}

void	display_tab_final(char **tab, int nb_tetriminos)
{
	int i;
	int j;

	i = 0;
	j = 0;
	while (i < nb_tetriminos)
	{
		j = 0;
		while (j < nb_tetriminos)
		{
			ft_putchar(tab[i][j]);
			j++;
		}
		ft_putstr("\n");
		i++;
	}
}

void 		ft_solve_final(list_tetriminos list, char **tab_final, char *combinaison, int nb_tetriminos)
{
	int		x;
	int		y;

	tab_square_minside = ft_square_min(nb_tetriminos);
	tab_square_maxside = ft_square_max(nb_tetriminos);
	tab_final = create_final_tab(NULL, tab_square_maxside);
	x = 0;
	y = 0;
	while (algory_comby(list, combinaison, tab_final, x, y) == 0)
	{
		tab_square_minside++;
		x = 0;
		y = 0;
	}
	display_tab_final(tab_final, tab_square_minside);
}
