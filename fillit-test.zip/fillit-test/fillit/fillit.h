/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fillit.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: isgandou <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/02/05 17:26:26 by isgandou          #+#    #+#             */
/*   Updated: 2018/07/05 13:25:55 by vjauze           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FILLIT_H
# define FILLIT_H

# include "../libft/libft.h"
# include <sys/types.h>
# include <sys/stat.h>
# include <fcntl.h>
# include <stdlib.h>

// Structure Tetrimino

typedef struct		Tetrimino
{
	char 	**tab;
	char	letter;
	struct	Tetrimino *next;
}			Tetrimino;

typedef Tetrimino* list_tetriminos;

// Structure Combinaison

typedef struct Combinaison
{
	char	*combinaison;
	int		case_vide;
	struct 	Combinaison *next;
}			Combinaison;

typedef Combinaison* list_combinaison;

int tab_square_minside;
int tab_square_maxside;

// test resolve

void		ft_init_solve(list_tetriminos list, int nb_tetriminos);
char		**create_final_tab(char **tab, int nb_tetriminos);

int 		algory_comby(Tetrimino *list, char *combinaison, char **tab, /*int square_size,*/ int x, int y);
int			algory_test(Tetrimino *list, char **tab, /*int square_size, */int x, int y);
char		**algory_pos(Tetrimino *list, char **tab, int x, int y);
char		**algory_rem(Tetrimino *list, char **tab);

char		ft_combyChar(int tetriminosCount);
list_tetriminos	ft_rechercheElement(list_tetriminos liste, char letter);
list_combinaison	ft_addCombinaison(list_combinaison,char *combinaison, int vide);
int ft_getVide(char **tab, int tab_square_minside);

void		ft_solve_final(list_tetriminos list, char **tab_final, char *combinaison, int nb_tetriminos);
void		display_tab_final(char **tab, int square_max);

int			ft_create_tetriminos(char *s);
list_tetriminos	addTetrimino(list_tetriminos list, char **tab, int letter);
char		*ft_changebloctoletter(char *s);
char		**ft_replace_tetrimino(char **tab);
char		**ft_replace_tetrimino_x_init(char **tab);
char		**ft_replace_tetrimino_x(char **tab);
char		**ft_replace_tetrimino_y_init(char **tab);
char		**ft_replace_tetrimino_y(char **tab);
char		**ft_init_tetrimino_tab(char *s);
char		**ft_strtotab(char **tab, char *s);
int			ft_nbtetrimino(char *s);
char		*ft_define_letter_tetrimino(char *s, int count);

int			ft_square_max(int nb_tetriminos);
int			ft_square_min(int nb_tetriminos);

int		ft_checkall(char *s);
char	*ft_read(const int fd);
int		ft_checkback(char *s);
int		ft_checkchar(char *s);
int		ft_checkcontactblock(char *s);
int		ft_checkendl(char *s);
int		ft_checklen(char *s);
int		ft_checknbblock(char *s);
int		ft_checkposblock(char *s);
int		ft_checksizeblock(char *s);

#endif
