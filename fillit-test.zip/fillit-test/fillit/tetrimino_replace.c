/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tetrimino_replace.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: isgandou <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/02/13 14:11:37 by isgandou          #+#    #+#             */
/*   Updated: 2018/02/14 18:04:27 by isgandou         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fillit.h"
#include "stdio.h"

char		**ft_replace_tetrimino(char **tab)
{
	tab = ft_replace_tetrimino_x_init(tab);
	tab = ft_replace_tetrimino_y_init(tab);
	return (tab);
}

char		**ft_replace_tetrimino_x_init(char **tab)
{
	int x;
	int case_count;
	int check_count;

	x = 0;
	case_count = 0;
	check_count = 0;
	while (check_count < 3)
	{
		x = 0;
		while (x < 4)
		{
			if (tab[0][x] == '.')
				case_count++;
			x++;
		}
		if (case_count == 4)
			tab = ft_replace_tetrimino_x(tab);
		case_count = 0;
		check_count++;
	}
	return (tab);
}

char		**ft_replace_tetrimino_x(char **tab)
{
	int	i;
	int	j;
	
	i = 0;
	j = 0;
	while (i < 4)
	{	
		j = 0;
		while (j < 4)
		{
			if (tab[i][j] != '.')
			{
				if (tab[i - 1][j])
				{
					tab[i - 1][j] = tab[i][j];
					tab[i][j] = '.';
				}

			}
			j++;
		}
		i++;
	}
	return (tab);
}

char		**ft_replace_tetrimino_y_init(char **tab)
{
	int y;
	int case_count;
	int check_count;

	y = 0;
	case_count = 0;
	check_count = 0;
	while (check_count < 3)
	{
		y = 0;
		while (y < 4)
		{
			if (tab[y][0] == '.')
				case_count++;
			y++;
		}
		if (case_count == 4)
			tab = ft_replace_tetrimino_y(tab);
		case_count = 0;
		check_count++;
	}
	return (tab);
}

char		**ft_replace_tetrimino_y(char **tab)
{
	int	i;
	int	j;
	
	i = 0;
	j = 0;
	while (i < 4)
	{	
		j = 0;
		while (j < 4)
		{
			if (tab[i][j] != '.')
			{
				if (tab[i][j - 1])
				{
					tab[i][j - 1] = tab[i][j];
					tab[i][j] = '.';
				}

			}
			j++;
		}
		i++;
	}
	return (tab);
}