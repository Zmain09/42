/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   autre.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vjauze <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/02/19 15:19:35 by vjauze            #+#    #+#             */
/*   Updated: 2018/02/19 15:20:26 by vjauze           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fillit.h"
#include <stdio.h>

char		*ft_define_letter_tetrimino(char *s, int count)
{
	int i;
	char letter;

	i = 0;
	letter = 'A' + count;
	while (s[i])
	{
		if (s[i] == '#')
			s[i] = letter;
		i++;
	}
	return (s);
}

int			ft_square_max(int nb_tetriminos)
{
	int i;

	i = 0;
	while (i * i < nb_tetriminos * 16)
		i++;
	return (i);
}

int			ft_square_min(int nb_tetriminos)
{
	int i;

	i = 0;
	while (i * i < nb_tetriminos * 4)
		i++;
	return (i);
}
