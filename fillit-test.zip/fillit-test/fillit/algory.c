/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   algo.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: isgandou <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/02/13 14:11:37 by isgandou          #+#    #+#             */
/*   Updated: 2018/07/05 13:25:09 by vjauze           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fillit.h"
#include <stdio.h>


void 		ft_init_solve(list_tetriminos list, int nb_tetriminos)
{
	char	**tab_final;
	char	*combinaison;
	int 	i;
	int		x;
	int		y;

	tab_square_minside = ft_square_min(nb_tetriminos);
	tab_square_maxside = ft_square_max(nb_tetriminos);
	tab_final = create_final_tab(NULL, tab_square_maxside);
	i = 0;
	x = 0;
	y = 0;
	while (i < nb_tetriminos)
	{
		*combinaison = ft_combyChar(nb_tetriminos);
		while (algory_comby(list, combinaison, tab_final, x, y) == 0)
		{
			tab_square_minside++;
			x = 0;
			y = 0;
		}
		ft_addCombinaison(list, combinaison, ft_getvide(tab_final, tab_square_minsize));
		i++;
	}
	ft_solve_final(list, tab_final, combinaison, tab_square_minside);
}

int	algory_comby(Tetrimino *list, char *combinaison, char **tab, int x, int y)
{
	if (list != NULL)
	{
		while (y * x < tab_square_minside * tab_square_minside)
		{
			if ((algory_test(list, tab, x, y)) == 1)
			{
				tab = algory_pos(list, tab, x, y);
				if (algory_comby(rechercheElement(list, *combinaison++), combinaison, tab, x, y) == 1)
					return (1);
				tab = algory_rem(list, tab);
			}
			if (x < tab_square_minside)
				x++;
			else {
				x = 0;
				y++;
			}
		}
		x = 0;
		y = 0;
		return (0);
	}
	return (1);
}

int	algory_test(Tetrimino *list, char **tab, int x, int y)
{
	int i;
	int j;

	i = 0;
	j = 0;
	while (i < 4)
	{
		j = 0;
		while (j < 4)
		{
			if (list->tab[i][j] == list->letter && (x + j >= tab_square_minside || y + i >= tab_square_minside))
				return (0);
			if (list->tab[i][j] == list->letter && ft_isalpha(tab[y + i][x + j]) == 1)
				return (0);
			j++;
		}
		i++;
	}
	return (1);
}

char	**algory_pos(Tetrimino *list, char **tab, int x, int y)
{
	int i;
	int j;

	i = 0;
	j = 0;
	while (i < 4)
	{
		j = 0;
		while (j < 4)
		{
			if (list->tab[i][j] == list->letter)
				tab[y + i][x + j] = list->letter;
			j++;
		}
		i++;
	}
	return (tab);
}

char	**algory_rem(Tetrimino *list, char **tab)
{
	int i;
	int j;

	i = 0;
	j = 0;
	while (i < tab_square_maxside)
	{
		j = 0;
		while (j < tab_square_maxside)
		{
			if (tab[i][j] == list->letter)
				tab[i][j] = '.';
			j++;
		}
		i++;
	}
	return (tab);
}
