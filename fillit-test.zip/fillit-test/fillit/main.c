/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: isgandou <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/02/05 16:26:02 by isgandou          #+#    #+#             */
/*   Updated: 2018/02/21 16:22:33 by isgandou         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fillit.h"

char		*ft_read(const int fd)
{
	char	buf[547];
	int		ret;

	if (!(ret = read(fd, buf, 546)))
		return (0);
	buf[ret] = '\0';
	return (ft_strdup(buf));
}

int		main(int ac, char **av)
{
	int	fd;
	int	result;
	char *source;

	result = 0;
	if (ac != 2)
	{
		ft_putendl("usage : ./fillit source_file");
		return (0);
	}
	fd = open(av[1], O_RDONLY);
	if (!(source = ft_read(fd)))
	{
		ft_putendl("error");
		return (0);
	}
	close(fd);
	if (ft_checkall(source) == 0)
	{
		ft_putendl("error");
		return (0);
	}
	result = ft_create_tetriminos(source);
	if (result == 0)
	{
		ft_putstr("error\n");
	}
	return (0);
}
