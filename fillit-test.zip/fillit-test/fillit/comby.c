/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   comby.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vjauze <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/07/05 10:09:53 by vjauze            #+#    #+#             */
/*   Updated: 2018/07/05 13:26:09 by vjauze           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fillit.h"

char ft_combyChar(int tetriminosCount) {

	int i;
	char random_letter;
	char *result;

	i = 0;
	random_letter = NULL;
	while (i < tetriminosCount) {	
		random_letter = 'A' + (rand() % 26);
		while(ft_strstr(result, random_letter) != NULL) {
			random_letter = 'A' + (rand() % 26);
		}
		result[i] = random_letter;
		i++;
	}
	return (result);
}

list_tetriminos ft_rechercheElement(list_tetriminos liste, char letter) {
	
	element *tmp;

	*tmp = liste;
	while (tmp != NULL) {
		if (tmp->letter == valeur) {
			return (tmp); // return address
		}
		tmp = tmp->next;
	}
	return (NULL);
}

list_combinaison ft_addCombinaison(list_combinaison list, char *combinaison, int vide)
{
	Combinaison* newCombinaison = malloc(sizeof(Combinaison));
	newCombinaison->combinaison = combinaison;
	newCombinaison->case_vide = vide;
	newCombinaison->next = NULL;
	if (list == NULL)
		return (newCombinaison);
	else
	{
		Combinaison* temp = list;
		while (temp->next != NULL)
			temp = temp->next;
		temp->next= newCombinaison;
		return (list);
	}
}

int	ft_getVide(char **tab, int tab_square_minside) {

	int x;
	int y;
	int count;

	x = 0;
	y = 0;
	count = 0;
	while (y * x < tab_square_minside * tab_square_minside)
	{
		if (tab[y][x] == '.')
			count++;
		if (x < tab_square_minside)
			x++;
		else {
			x = 0;
			y++;
		}
	}
	return (count);
}
























