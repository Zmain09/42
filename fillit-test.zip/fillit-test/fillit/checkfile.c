/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checkfile.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: isgandou <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/02/06 14:48:55 by isgandou          #+#    #+#             */
/*   Updated: 2018/02/21 16:01:24 by isgandou         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fillit.h"

int			ft_checkall(char *s)
{
	if (ft_checklen(s) == 0)
		return (0);
	if (ft_checkchar(s) == 0)
		return (0);
	if (ft_checkback(s) == 0)
		return (0);
	if (ft_checkendl(s) == 0)
		return (0);
	if (ft_checknbblock(s) == 0)
		return (0);
	if (ft_checkposblock(s) == 0)
		return (0);
	return (1);
}

int			ft_checklen(char *s)
{
	int		i;

	i = 0;
	while (s[i])
	{
		if (s[545] != '\0')
			return (0);
		i++;
	}
	return (1);
}

int			ft_checkchar(char *s)
{
	int		i;

	i = 0;
	while (s[i])
	{
		if (s[i] != '#' && s[i] != '.' && s[i] != '\n')
			return (0);
		i++;
	}
	return (1);
}

int			ft_checkback(char *s)
{
	if (s[ft_strlen(s) - 2] == '\n')
		return (0);
	return (1);
}

int			ft_checkendl(char *s)
{
	int		count;
	int		i;
	int		line;

	count = 0;
	i = 0;
	line = 0;
	while (s[i])
	{
		if (s[i] == '\n')
		{
			if (i == 4 + 5 * line + count && line < count * 4 + 4)
				line++;
			else
			{
				count++;
				if (i != 4 + 5 * (line - 1) + count)
					return (0);
			}
		}
		i++;
	}
	return (1);
}
